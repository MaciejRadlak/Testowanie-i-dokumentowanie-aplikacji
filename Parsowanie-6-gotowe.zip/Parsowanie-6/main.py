import re
import csv

pattern = re.compile(
    r"Czas sortowania \((?P<tryb>indeksy|wskazniki)\)"
    r"(?:\s*\[N=(?P<N>\d+)\])?"
    r"\s*:\s*(?P<czas>\d+(?:\.\d+)?)\s*s"
)

rows = []

with open("wyniki.txt", "r", encoding="utf-8") as f:
    for line in f:
        m = pattern.search(line)
        if m:
            d = m.groupdict()

            czas_s = float(d.get("czas"))
            czas_ms = czas_s * 1000  

            rows.append({
                "tryb": d.get("tryb"),
                "N": d.get("N"),
                "czas_s": czas_s,
                "czas_ms": czas_ms
            })
        else:
            print("Nie rozpoznano linii:", line.strip())

# zapis do CSV
with open("wyniki.csv", "w", encoding="utf-8-sig", newline="") as f:
    writer = csv.DictWriter(
        f,
        fieldnames=["tryb", "N", "czas_s", "czas_ms"],
        delimiter=';'
    )
    writer.writeheader()
    writer.writerows(rows)

print("Dane zapisano do pliku wyniki.csv")
