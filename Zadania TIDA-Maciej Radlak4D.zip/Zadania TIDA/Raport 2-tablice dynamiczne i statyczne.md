# Sprawozdanie z zajęć „Testowanie i dokumentowanie aplikacji”

| | |
| :--- | :--- |
| **Temat:** | **Tablice dynamiczne i statyczne, zarządzanie pamięcią, testy funkcjonalne i wydajnościowe** |
| **Wykonawca:** | **Maciej Radlak** |
| **Data:** | **28.11.2025** |
| **Klasa:** | **4D (technik programista)** |
| **Poziom:** | **Podstawowy** |

---

### Cel ćwiczenia
1. Zrozumienie różnicy między tablicą statyczną (alokowaną na stosie) a dynamiczną (alokowaną na stercie).
2. Zbadanie wpływu rozmiaru tablicy na czas sortowania.
3. Wykonanie testów funkcjonalnych i wydajnościowych.
4. Porównanie działania programu w architekturach x86 (32-bit) i x64 (64-bit).
5. Zidentyfikowanie limitu stosu (moment wystąpienia błędu stack overflow).

### Środowisko testowe

| Parametr | Wartość |
| :--- | :--- |
| System operacyjny | Windows 11 64-bit |
| Kompilator | Microsoft Visual C++ 2022 |
| Tryby kompilacji | x86 (32-bit), x64 (64-bit) |
| Typ projektu | Konsolowa aplikacja C++ |
| Procesor | Intel Core i5-10400F @ 2.9 GHz |
| Pamięć RAM | 16 GB |

### Opis programu
Program sortuje tablicę liczb losowych metodą sortowania bąbelkowego (Bubble Sort) i mierzy czas wykonania. Testuje dwa przypadki:
1. **Tablica statyczna** – utworzona na stosie.
2. **Tablica dynamiczna** – utworzona na stercie (za pomocą `new` i `delete`).

Dodatkowo program wykonuje test funkcjonalny, który sprawdza:
* czy tablica istnieje,
* czy zawiera wartości z zadanego zakresu (0-1000),
* czy jest posortowana rosnąco.

Pomiar czasu jest wykonywany w mikrosekundach/milisekundach przy pomocy biblioteki `<chrono>`.

### Przebieg doświadczenia
1. Uruchomiono program dla tablic o rozmiarach: 1 000, 10 000, 100 000 elementów.
2. Dla każdego rozmiaru wykonano dwa testy:
    * tablica statyczna,
    * tablica dynamiczna.
3. Dodatkowo sprawdzono maksymalny rozmiar tablicy statycznej możliwy do zaalokowania bez błędu *stack overflow*.
4. Program uruchomiono osobno w wersjach x86 i x64 (tryb Debug).

### Wyniki pomiarów

**Tabela 1 – Czas sortowania (w milisekundach)**

| Rozmiar tablicy | Typ tablicy | Czas (x86) | Czas (x64) | Test funkcjonalny |
| :--- | :--- | :--- | :--- | :--- |
| 1 000 | statyczna | 48 ms | 4 ms | zaliczony |
| 1 000 | dynamiczna | 22 ms | 5 ms | zaliczony |
| 10 000 | statyczna | 1 022 ms | 452 ms | zaliczony |
| 10 000 | dynamiczna | 755 ms | 458 ms | zaliczony |
| 100 000 | statyczna | 70 110 ms | 42 414 ms | zaliczony |
| 100 000 | dynamiczna | 70 404 ms | 42 698 ms | zaliczony |

**Tabela 2 – Maksymalny rozmiar tablicy statycznej**

| Architektura | Maks. rozmiar (elementów) | Komentarz |
| :--- | :--- | :--- |
| x86 (32-bit) | ~250 000 | Błąd Stack Overflow powyżej tej wartości |
| x64 (64-bit) | ~2 000 000 | Większy stos pozwala na większe tablice |

### Analiza wyników
1. **Porównanie typów tablic:** W większości przeprowadzonych testów (szczególnie w wersji x64) tablice statyczne były sortowane nieznacznie szybciej lub w zbliżonym czasie do dynamicznych. Różnice te zacierają się przy bardzo dużych zbiorach danych w trybie Debug.
2. **Architektura x64 vs x86:** Kod 64-bitowy okazał się zdecydowanie szybszy (nawet dwukrotnie w przypadku dużych tablic: ~42s vs ~70s). Wynika to z lepszej optymalizacji, szerszych rejestrów i efektywniejszego zarządzania pamięcią w trybie 64-bitowym.
3. **Limit stosu:** W architekturze x86 limit tablicy statycznej wyniósł ok. 250 000 elementów, podczas gdy w x64 udało się zaalokować aż 2 000 000 elementów. Jest to dowód na to, że aplikacje 64-bitowe mają domyślnie większy rozmiar stosu lub efektywniej nim zarządzają.
4. **Pamięć:** W przypadku tablic dynamicznych jedynym ograniczeniem była dostępna pamięć RAM, co czyni je lepszym rozwiązaniem dla bardzo dużych zbiorów danych, mimo narzutu związanego z alokacją na stercie.

### Wnioski końcowe
1. Tablice statyczne są szybkie w alokacji i dostępie, ale ich rozmiar jest ściśle ograniczony wielkością stosu. Przekroczenie limitu prowadzi do krytycznego błędu *Stack Overflow*.
2. Tablice dynamiczne, mimo iż operują na stercie (co może być minimalnie wolniejsze ze względu na *cache miss*), są niezbędne przy przetwarzaniu dużych ilości danych, gdzie rozmiar przekracza pojemność stosu.
3. Architektura x64 zapewnia znaczący przyrost wydajności i stabilności dla dużych struktur danych w porównaniu do x86.
4. Należy unikać tworzenia wielkich tablic na stosie; dla struktur powyżej kilkudziesięciu tysięcy elementów zalecane jest stosowanie alokacji dynamicznej (np. `std::vector` lub `new`).

---

### Załącznik – przykładowe fragmenty kodu

```cpp
bool czyTablicaPoprawna(int* tablica, int rozmiar, int MIN, int MAX) {
    if (!tablica) return false;
    for (int i = 0; i < rozmiar; i++) {
        if (tablica[i] < MIN || tablica[i] > MAX) return false;
    }
    return true;
}

bool czyTablicaPosortowana(int* tablica, int rozmiar) {
    for (int i = 1; i < rozmiar; i++) {
        if (tablica[i - 1] > tablica[i]) return false;
    }
    return true;
}