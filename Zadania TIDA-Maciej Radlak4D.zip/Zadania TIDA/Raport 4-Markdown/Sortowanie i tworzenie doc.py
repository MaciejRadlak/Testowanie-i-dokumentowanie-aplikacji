import platform
import random
import time
import datetime
import matplotlib.pyplot as plt
import os

# Nazwa pliku wykresu
CHART_FILE = "wykres_sortowania.png"

def zapisz_wykres(test_results, filename=CHART_FILE):
    sizes = list(test_results.keys())
    times = list(test_results.values())

    plt.figure(figsize=(8, 5))
    plt.plot(sizes, times, marker='o', linestyle='-', color='blue')
    plt.title("Czas sortowania vs rozmiar tablicy")
    plt.xlabel("Rozmiar tablicy")
    plt.ylabel("Czas (s)")
    plt.grid(True)
    plt.savefig(filename)
    plt.close()

def mierzczas():
    # Zwiększono zakresy, aby wyniki były ciekawsze
    sizes = [1000, 5000, 10000, 20000, 50000]
    results = {}

    for size in sizes:
        # Generowanie losowej tablicy
        arr = [random.randint(0, 100000) for _ in range(size)]

        start = time.time()
        sorted_arr = sorted(arr) # Sortowanie w Pythonie (Timsort)
        end = time.time()

        results[size] = end - start

    return results

def generuj_raport(test_results):
    filename = f"Raport_TiDA_04_{datetime.date.today()}.md"
    
    # Dane do nagłówka
    temat = "Automatyczne generowanie dokumentacji testów w formacie Markdown"
    wykonawca = "Maciej Radlak" # Możesz zmienić na input() lub zmienną
    klasa = "4D (technik programista)"
    poziom = "Podstawowy"

    with open(filename, "w", encoding="utf-8") as f:
        # --- TYTUŁ ---
        f.write("# Sprawozdanie z zajęć „Testowanie i dokumentowanie aplikacji”\n\n")

        # --- TABELA NAGŁÓWKOWA (wg wzoru TiDA 00) ---
        f.write("| | |\n")
        f.write("| :--- | :--- |\n")
        f.write(f"| **Temat:** | **{temat}** |\n")
        f.write(f"| **Wykonawca:** | **{wykonawca}** |\n")
        f.write(f"| **Data:** | **{datetime.date.today()}** |\n")
        f.write(f"| **Klasa:** | **{klasa}** |\n")
        f.write(f"| **Poziom:** | **{poziom}** |\n")
        f.write("\n---\n\n")

        # --- 1. CEL ĆWICZENIA ---
        f.write("### Cel ćwiczenia\n")
        f.write("1. Automatyzacja procesu testowania wydajności algorytmów sortowania.\n")
        f.write("2. Generowanie raportów z testów w formacie Markdown z poziomu kodu Python.\n")
        f.write("3. Wizualizacja wyników pomiarów za pomocą biblioteki Matplotlib.\n")
        f.write("4. Zrozumienie struktury dokumentacji technicznej i raportowania błędów.\n\n")

        # --- 2. ŚRODOWISKO TESTOWE ---
        # Automatyczne pobieranie danych o systemie
        f.write("### Środowisko testowe\n\n")
        f.write("| Parametr | Wartość |\n")
        f.write("| :--- | :--- |\n")
        f.write(f"| System operacyjny | {platform.system()} {platform.release()} |\n")
        f.write(f"| Wersja systemu | {platform.version()} |\n")
        f.write(f"| Procesor | {platform.processor()} |\n")
        f.write(f"| Interpreter Python | {platform.python_version()} |\n")
        f.write(f"| Biblioteka wykresów | Matplotlib |\n\n")

        # --- 3. OPIS PROGRAMU ---
        f.write("### Opis programu\n")
        f.write("Skrypt napisany w języku Python realizuje test wydajności wbudowanej funkcji sortującej `sorted()` (algorytm Timsort). \n")
        f.write("Program generuje losowe tablice liczb całkowitych o zadanych rozmiarach, a następnie mierzy czas ich sortowania. \n")
        f.write("Po zakończeniu pomiarów skrypt automatycznie:\n")
        f.write("* Generuje wykres liniowy zależności czasu od liczby elementów.\n")
        f.write("* Tworzy niniejszy plik raportu w formacie Markdown.\n\n")

        # --- 4. PRZEBIEG DOŚWIADCZENIA ---
        f.write("### Przebieg doświadczenia\n")
        f.write("1. Zdefiniowano listę rozmiarów tablic do przetestowania.\n")
        f.write("2. Dla każdego rozmiaru wygenerowano losowe dane wejściowe.\n")
        f.write("3. Zmierzono czas sortowania przy użyciu biblioteki `time`.\n")
        f.write("4. Dane zebrano w słowniku i przekazano do funkcji generującej wykres oraz raport.\n\n")

        # --- 5. WYNIKI POMIARÓW ---
        f.write("### Wyniki pomiarów\n\n")
        f.write("**Tabela 1 – Czas sortowania (w sekundach)**\n\n")
        f.write("| Rozmiar tablicy | Czas wykonania (s) |\n")
        f.write("| :--- | :--- |\n")
        
        for size, czas in test_results.items():
            f.write(f"| {size} | {czas:.6f} s |\n")
        
        f.write("\n**Wykres zależności czasu od rozmiaru danych:**\n\n")
        f.write(f"![Wykres sortowania]({CHART_FILE})\n\n")

        # --- 6. ANALIZA WYNIKÓW ---
        f.write("### Analiza wyników\n")
        f.write("1. Czas sortowania rośnie wraz ze wzrostem liczby elementów w tablicy.\n")
        f.write("2. Dla małych tablic (1000-5000 elementów) czas jest bliski zeru.\n")
        f.write("3. Język Python, mimo bycia językiem interpretowanym, posiada bardzo wydajną implementację sortowania (Timsort).\n")
        f.write("4. Wykres potwierdza nieliniowy wzrost czasu wykonywania operacji (złożoność O(n log n)).\n\n")

        # --- 7. WNIOSKI KOŃCOWE ---
        f.write("### Wnioski końcowe\n")
        f.write("1. Automatyzacja raportowania pozwala zaoszczędzić czas i eliminuje błędy przy przepisywaniu wyników.\n")
        f.write("2. Format Markdown jest czytelny i łatwy do konwersji na PDF lub HTML.\n")
        f.write("3. Biblioteka `platform` pozwala na łatwe dokumentowanie środowiska uruchomieniowego, co jest kluczowe dla powtarzalności testów.\n\n")

        # --- 8. ZAŁĄCZNIK (KOD ŹRÓDŁOWY) ---
        f.write("---\n")
        f.write("### Załącznik – Kod źródłowy programu\n")
        f.write("```python\n")
        # Odczytujemy kod własnego pliku, żeby wstawić go do raportu
        try:
            with open(__file__, "r", encoding="utf-8") as source_code:
                f.write(source_code.read())
        except Exception:
            f.write("# Nie udało się odczytać pliku źródłowego.")
        f.write("\n```\n")

    print(f"Raport zapisano do pliku: {filename}")

# --- URUCHOMIENIE ---
if __name__ == "__main__":
    results = mierzczas()
    zapisz_wykres(results)
    generuj_raport(results)