# Sprawozdanie z zajec „Testowanie i dokumentowanie aplikacji”

| | |
| :--- | :--- |
| **Temat:** | **TiDA 03: Tablice deterministyczne i testy powtarzalnosci** |
| **Wykonawca:** | **Maciej Radlak** |
| **Data:** | **28.11.2025** |
| **Klasa:** | **4D (technik programista)** |
| **Poziom:** | **Podstawowy** |

---

### Cel cwiczenia
1. [cite_start]Zrozumienie pojecia powtarzalnosci eksperymentu przy uzyciu ziarna losowosci (`srand`, `seed`)[cite: 73, 78].
2. [cite_start]Porownanie czasow sortowania dla roznych rozkladow danych: tablica posortowana, odwrocona i losowa[cite: 75].
3. [cite_start]Zbadanie wplywu optymalizacji algorytmu Bubble Sort (flaga `swapped`) na czas wykonania[cite: 202].
4. [cite_start]Analiza zlozonosci obliczeniowej $O(n^2)$ w praktyce[cite: 180].

### Srodowisko testowe

| Parametr | Wartosc |
| :--- | :--- |
| System operacyjny | Windows 11 64-bit |
| Kompilator | Microsoft Visual C++ 2022 |
| Procesor | Intel Core i5-10400F @ 2.9 GHz |
| Typ projektu | Konsolowa aplikacja C++ |
| Metoda pomiaru | `std::chrono::high_resolution_clock` (mikrosekundy) |

### Opis programu
Program testuje wydajnosc algorytmu sortowania babelkowego w dwoch wariantach:
1. [cite_start]**Standardowy:** Klasyczna implementacja z dwiema petlami `for`, wykonujaca pelna liczbe porownan niezaleznie od ukladu danych[cite: 126].
2. **Zoptymalizowany:** Implementacja z flaga `bool swapped`. [cite_start]Jesli wewnetrzna petla nie wykona zadnej zamiany, algorytm konczy dzialanie wczesniej[cite: 202].

[cite_start]Program generuje trzy typy tablic deterministycznych (staly `seed` = 123)[cite: 85]:
* **Posortowana:** Najlepszy przypadek (elementy rosnaco).
* **Odwrotna:** Najgorszy przypadek (elementy malejaco).
* **Losowa:** Przypadek przecietny.

### Przebieg doswiadczenia
1. Uruchomiono testy dla trzech wielkosci zbioru danych: $N=1000$, $N=2000$, $N=5000$.
2. Dla kazdego $N$ zmierzono czas sortowania w trybie Standardowym oraz Zoptymalizowanym.
3. Kazdy pomiar wykonano dla trzech typow rozkladu danych (Posortowana, Odwrotna, Losowa).
4. Wyniki czasu zapisano w mikrosekundach (`us`).

### Wyniki pomiarow

**Tabela 1 – Zestawienie czasow sortowania (w mikrosekundach)**

| N | Typ danych | Standardowy Bubble Sort | Zoptymalizowany Bubble Sort | Zysk/Strata |
| :---: | :--- | :---: | :---: | :---: |
| **1000** | Posortowana | 989 us | **1 us** | Ogromny zysk |
| | Odwrotna | 3 772 us | 3 397 us | Zblizony czas |
| | Losowa | 3 129 us | 2 321 us | Umiarkowany zysk |
| **2000** | Posortowana | 3 048 us | **4 us** | Ogromny zysk |
| | Odwrotna | 15 213 us | 16 733 us | Narzut flagi |
| | Losowa | 9 433 us | 10 895 us | Narzut flagi |
| **5000** | Posortowana | 23 976 us | **9 us** | Ogromny zysk |
| | Odwrotna | 136 412 us | 236 692 us | Duza strata |
| | Losowa | 138 785 us | 114 062 us | Umiarkowany zysk |

### Analiza wynikow
1. **Najlepszy przypadek (Tablica Posortowana):**
   Wersja zoptymalizowana dziala w czasie bliskim zeru (1-9 us). [cite_start]Dzieki fladze `swapped` algorytm wykrywa posortowanie juz po pierwszym przejsciu, redukujac zlozonosc z $O(n^2)$ do $O(n)$[cite: 173, 202].
2. **Najgorszy przypadek (Tablica Odwrotna):**
   Dla $N=5000$ wersja zoptymalizowana okazala sie znacznie wolniejsza (236 ms vs 136 ms). Wynika to z faktu, ze w najgorszym scenariuszu (kazdy element wymaga zamiany) obsluga flagi i dodatkowe instrukcje warunkowe wprowadzaja narzut (overhead), ktory przy duzej liczbie operacji przewyzsza korzysci.
3. **Wzrost czasu ($O(n^2)$):**
   Przy zwiekszeniu $N$ z 1000 do 5000 (5-krotnie), czas sortowania odwrotnego w wersji standardowej wzrosl z ~3.7 ms do ~136 ms (ok. 36 razy). [cite_start]Jest to zgodne z teoretyczna zlozonoscia kwadratowa ($5^2 = 25$), powiekszona o czynniki sprzetowe (cache miss)[cite: 180].

### Wnioski koncowe
1. Optymalizacja Bubble Sort (flaga `swapped`) ma sens **tylko** w przypadku danych czesciowo lub calkowicie posortowanych. W przypadkach pesymistycznych moze pogorszyc wydajnosc przez dodatkowy narzut instrukcji.
2. [cite_start]Zastosowanie stałego ziarna (`seed`) pozwolilo na uzyskanie wiarygodnych, powtarzalnych wynikow dla tablicy "Losowej"[cite: 80].
3. Algorytm Bubble Sort, nawet w wersji zoptymalizowanej, jest nieefektywny dla duzych zbiorow danych ($N > 5000$) ze wzgledu na kwadratowa zlozonosc obliczeniowa.

---

### Zalacznik – fragmenty kodu

**Listing 1. Generowanie deterministyczne**
```cpp
void fill_random(int* tab, int n, unsigned int seed) {
    srand(seed); // Gwarancja powtarzalnosci
    for (int i = 0; i < n; i++) {
        tab[i] = rand() % 1000;
    }
}
```
### Zalacznik – fragmenty kodu

**Listing 2. Zoptymalizowany Bubble Sort**
```cpp
void bubble_sort_optimized(int* tab, int n) {
    for (int i = 0; i < n - 1; i++) {
        bool swapped = false;
        for (int j = 0; j < n - i - 1; j++) {
            if (tab[j] > tab[j + 1]) {
                std::swap(tab[j], tab[j + 1]);
                swapped = true;
            }
        }
        if (!swapped) break; // Przerwanie jesli posortowane
    }
}
```