# Sprawozdanie z zajec „Testowanie i dokumentowanie aplikacji”

| | |
| :--- | :--- |
| **Temat:** | **TiDA 01: Sortowanie babelkowe: indeksy i wskazniki (wersja podstawowa)** |
| **Wykonawcy:** | **Maciej Radlak** |
| **Data:** | **28.11.2025** |
| **Klasa:** | **4D (technik programista)** |
| **Poziom:** | **Podstawowy** |

---

### Cel cwiczenia
1. Zrozumienie dzialania algorytmu sortowania babelkowego (Bubble Sort).
2. Porownanie wydajnosci dwoch implementacji algorytmu: z uzyciem indeksowania tablic i z uzyciem arytmetyki wskaznikow.
3. Praktyczna nauka mierzenia czasu wykonania programu w jezyku C++ (biblioteka `chrono`).
4. Zbadanie roznic w wynikach pomiarow miedzy kompilacja w trybie **Debug** a trybie **Release**.

### Srodowisko testowe

| Parametr | Wartosc |
| :--- | :--- |
| Jezyk programowania | C++ (standard C++11 lub wyzszy) |
| Srodowisko (IDE) | Visual Studio / inne IDE C++ |
| Kompilator | MSVC / GCC (wersje 32-bit i 64-bit) |
| Biblioteki | `chrono` (do pomiaru czasu), `iostream`, `cstdlib` |
| Algorytm | Sortowanie babelkowe (Bubble Sort) |
| Wielkosci danych ($N$) | 1 000, 10 000, 100 000 elementow |

### Opis programu
Program napisany w jezyku C++ zawiera dwie glowne funkcje sortujace oraz sekcje testujaca.
1. **Funkcje sortujace:**
    * `bubbleSortIndex(int arr[], int n)`: Implementacja sortowania babelkowego wykorzystujaca standardowe **indeksowanie tablic** (`arr[j]`, `arr[j+1]`).
    * `bubbleSortPointer(int* arr, int n)`: Implementacja sortowania babelkowego wykorzystujaca **arytmetyke wskaznikow** (`*p`, `*(p+1)`).
2. **Sekcja testujaca (`main`):** Program generuje losowe tablice o zadanych rozmiarach ($N$) i mierzy czas sortowania dla kazdej z dwoch implementacji (`Index` i `Pointer`) dla tablic $N=1000$, $N=10000$ oraz $N=100000$. Do pomiaru czasu wykorzystano funkcje `high_resolution_clock::now()` oraz `duration_cast<milliseconds>`.

### Przebieg doswiadczenia
1. Utworzono projekt w Visual Studio i zaimplementowano kod sortowania oraz funkcje testujace.
2. Skompilowano i uruchomiono program **w trybie Debug**, a nastepnie zapisano czasy wykonania dla obu wersji sortowania i trzech roznych rozmiarow danych.
3. Skompilowano i uruchomiono program **w trybie Release** (bez optymalizacji debuggera i kontroli), a nastepnie ponownie zapisano czasy wykonania.
4. Porownano uzyskane wyniki pomiarow, zwracajac szczegolna uwage na roznice w wydajnosci miedzy trybem `Debug` a `Release` oraz miedzy wersja `index` a `pointer`.

### Wyniki pomiarow

**Tabela 1 – Zestawienie czasow sortowania [ms] w trybie DEBUG**

| Wielkosc danych ($N$) | Sortowanie Indeksowe | Sortowanie Wskaznikowe |
| :---: | :---: | :---: |
| 1 000 | 2 ms | 2 ms |
| 10 000 | 261 ms | 262 ms |
| 100 000 | 31 987 ms | 29 135 ms |

**Tabela 2 – Zestawienie czasow sortowania [ms] w trybie RELEASE**

| Wielkosc danych ($N$) | Sortowanie Indeksowe | Sortowanie Wskaznikowe |
| :---: | :---: | :---: |
| 1 000 | 0 ms | 0 ms |
| 10 000 | 0 ms | 0 ms |
| 100 000 | 0 ms | 0 ms |

### Analiza wynikow
1. **Porownanie implementacji (tryb Debug):** Dla malych rozmiarow tablic ($N=1000, N=10000$) roznice w czasie wykonania miedzy wersja indeksowa a wskaznikowa sa minimalne. Natomiast dla najwiekszej tablicy ($N=100000$), **wersja wskaznikowa** okazala sie **nieznacznie szybsza** (ok. 2,8 s roznicy). Wynika to z eliminacji operacji indeksowania tablicy, ktore na tym poziomie wydajnosci moga byc zoptymalizowane przez bezposrednie operacje na wskaznikach pamieci.
2. **Wiarygodnosc pomiarow (Debug vs. Release):** Pomiary w trybie **Release** (Tabela 2) sa niewiarygodne (uzyskano 0 ms), co sugeruje, ze dla zoptymalizowanego kodu sortowanie $10^5$ elementow zajelo mniej czasu niz wynosi minimalna rozdzielczosc uzytego zegara.
3. **Wplyw trybu Debug:** Tryb Debug wylacza wiekszosc optymalizacji kompilatora i dodaje mechanizmy kontroli i debugowania, co znaczaco wplywa na czas wykonania, czyniac go **niewiarygodnym** dla testow wydajnosciowych.

### Wnioski koncowe
1. Implementacja sortowania babelkowego za pomoca **arytmetyki wskaznikow** jest teoretycznie (i w testach na nieoptymalizowanym kodzie) nieznacznie wydajniejsza dla duzych struktur danych, poniewaz eliminuje kosztowne operacje indeksowania.
2. Mierzenie wydajnosci powinno odbywac sie **wylacznie** w trybie **Release**, ktory aktywuje optymalizacje kompilatora. Wyniki z trybu Debug sluza jedynie do analizy logiki programu, a nie jego predkosci.
3. Sortowanie babelkowe (Bubble Sort) ma bardzo slaba zlozonosc czasowa ($O(N^2)$), co potwierdza gwaltowny wzrost czasu wykonania przy przejsciu z $N=10 000$ (setki ms) do $N=100 000$ (dziesiatki sekund).

---

### Zalacznik – przykladowe fragmenty kodu

**Listing 1. Definicja funkcji sortowania indeksowego (`bubbleSortIndex`)**

```cpp
void bubbleSortIndex(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

```
**Listing 2. Definicja funkcji sortowania wskaznikowego (bubbleSortPointer)**
```cpp
void bubbleSortPointer(int* arr, int n) {
    for (int i = 0; i < n - 1; i++) {
        int* end = arr + n - i - 1;
        for (int* p = arr; p < end; ++p) {
            if (*p > *(p + 1)) {
                int temp = *p;
                *p = *(p + 1);
                *(p + 1) = temp;
            }
        }
    }
}

```
**Listing 3. Fragment kodu do pomiaru czasu (sekcja testowa)**
```cpp
// ---------------- POINTER ----------------
start = high_resolution_clock::now();
bubbleSortPointer(list2_100000, SIZE_3);
stop = high_resolution_clock::now();
cout << "Pointer 100000: " << duration_cast<milliseconds>(stop - start).count() << " ms\n";

// Przywrocenie pierwotnego stanu (dla kolejnego testu)
std::copy(list1_100000, list1_100000 + SIZE_3, list2_100000); 

// ---------------- INDEX ----------------
start = high_resolution_clock::now();
bubbleSortIndex(list2_100000, SIZE_3);
stop = high_resolution_clock::now();
cout << "Index 100000: " << duration_cast<milliseconds>(stop - start).count() << " ms\n";

```