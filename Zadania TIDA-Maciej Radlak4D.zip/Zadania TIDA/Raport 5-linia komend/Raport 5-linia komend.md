# Sprawozdanie z zajec „Testowanie i dokumentowanie aplikacji”

| | |
| :--- | :--- |
| **Temat:** | **TiDA 05: Kompilacja z linii komend + Python** |
| **Wykonawca:** | **Maciej Radlak** |
| **Data:** | **28.11.2025** |
| **Klasa:** | **4D (technik programista)** |
| **Poziom:** | **Podstawowy** |

---

### Cel cwiczenia
1. Nauczenie sie budowania i uruchamiania programu C++ z poziomu linii komend (CLI) przy uzyciu kompilatora MSVC (`cl.exe`).
2. Stworzenie skryptu automatyzujacego w jezyku Python, ktory kompiluje kod, uruchamia go i zapisuje wynik do pliku logu.
3. Porownanie kompilacji w trybie **Debug** (`/Od /MDd`) oraz **Release** (`/O2 /MD`).
4. Zrozumienie podstaw dzialania systemow Continuous Integration (CI) poprzez automatyzacje procesu build-test-report.

### Srodowisko testowe

| Parametr | Wartosc |
| :--- | :--- |
| System operacyjny | Windows 11 64-bit |
| Kompilator C++ | MSVC (Microsoft Visual C++) - cl.exe |
| Jezyk skryptowy | Python 3.x |
| Narzedzie | Developer Command Prompt for VS 2022 |
| Pliki zrodlowe | `main.cpp`, `build_and_run.py` |

### Opis programu
Cwiczenie skladalo sie z dwoch czesci programistycznych:
1.  **Program C++ (`main.cpp`):** Prosta aplikacja konsolowa, ktora wypisuje komunikat powitalny ("Hello Maciek") na standardowe wyjscie. Kod zostal zmodyfikowany wzgledem wzoru, aby zawieral imie autora.
2.  **Skrypt Python (`build_and_run.py`):** Narzedzie automatyzujace. Wykorzystuje biblioteke `subprocess` do wywolania kompilatora `cl.exe` z odpowiednimi flagami, nastepnie uruchamia powstaly plik `.exe`, przechwytuje jego wyjscie i zapisuje je do pliku tekstowego z unikalna nazwa (sygnatura czasowa). Skrypt dodaje rowniez stopke "KONIEC LOGU".

### Przebieg doswiadczenia
1.  Utworzono plik `main.cpp` i zmodyfikowano wyswietlany tekst na "Hello Maciek" (zgodnie z zadaniem 3).
2.  Skompilowano program recznie z linii komend w dwoch wariantach, aby zweryfikowac dzialanie kompilatora `cl`.
3.  Napisano skrypt `build_and_run.py`, ktory automatyzuje proces.
4.  Uruchomiono skrypt dla wersji **Release** (flagi `/O2 /MD`).
5.  Uruchomiono skrypt dla wersji **Debug** (flagi `/Od /MDd`).
6.  Porownano uzyskane pliki logow oraz wielkosc plikow wynikowych `.exe`.

### Wyniki pomiarow

**Tabela 1 – Porownanie wynikow kompilacji**

| Wersja | Flagi kompilatora | Wynik w logu | Rozmiar pliku .exe |
| :--- | :--- | :--- | :--- |
| **Release** | `/O2 /MD` | Hello Maciek | Mniejszy (optymalizacja) |
| **Debug** | `/Od /MDd` | Hello Maciek | Wiekszy (+4 kB) |

**Tresc wygenerowanych logow:**

*Log 1: `output_20251121_081609.log` (Release)*
```text
Hello Maciek

Uzyta wersja : Release 
KONIEC LOGU
```
*Log 2:`output_20251121_081756.log (Debug)`*
```text
Hello Maciek

Uzyta wersja : Release 
KONIEC LOGU
```
### Analiza wynikow
1. Porownanie wyjscia: Efekt dzialania programu (tekst wyswietlany na ekranie) jest identyczny w obu przypadkach. Uzytkownik koncowy nie widzi roznicy w funkcjonalnosci podstawowej.

2. Roznice w plikach: Plik wykonywalny w wersji Debug zwiekszyl swoj rozmiar o okolo 4kB wzgledem wersji Release. Jest to spodziewane zachowanie, poniewaz flaga /Od wylacza optymalizacje, a /MDd dolacza biblioteke debugowa, co zwieksza objetosc kodu wynikowego.

3. Automatyzacja: Skrypt Python poprawnie przechwycil wyjscie programu C++ i dopisal wymagana fraze "KONIEC LOGU", co potwierdza mozliwosc latwego tworzenia raportow z testow automatycznych.

### Wnioski koncowe
1.Kompilacja z linii komend daje wieksza kontrole nad procesem budowania aplikacji niz korzystanie wylacznie z IDE (klikniecie "Build").

2.Python i modul subprocess stanowia skuteczne narzedzie do tworzenia prostych potokow CI (Continuous Integration), umozliwiajac automatyczne budowanie i testowanie kodu.

3.Wersje Debug i Release roznia sie rozmiarem i wydajnoscia, mimo ze ich podstawowe dzialanie wyglada identycznie. Do ostatecznego wdrozenia nalezy zawsze stosowac wersje Release (/O2).
### Zalacznik – kody zrodlowe
**Listing 1. Program C++ (main.cpp)**
```
#include <iostream>
using namespace std;

int main(){
    cout<<"Hello Maciek"<<endl;
    return 0;
}
```
**Listing 2. Skrypt automatyzujacy (build_and_run.py)**
```
import subprocess,datetime

source="main.cpp"
exe="program.exe"

# Kompilacja w trybie Debug (/Od - brak optymalizacji, /MDd - debug runtime)
subprocess.check_call(["cl",source,"/Od","/MDd",f"/Fe{exe}"])

result=subprocess.run([exe],capture_output=True,text=True)

stamp=datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
log_name=f"output_{stamp}.log"

with open (log_name, "w", encoding ="utf-8")as f:
    f.write(result.stdout+"\n")
    f.write("Uzyta wersja : Debug \n")
    f.write("KONIEC LOGU \n")
    
print("Zapisano:",log_name)
```