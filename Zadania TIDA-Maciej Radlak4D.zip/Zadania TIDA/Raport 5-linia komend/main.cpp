#include <iostream>
using namespace std;

int main(){
    cout<<"Hello Maciek"<<endl;
    return 0;
}