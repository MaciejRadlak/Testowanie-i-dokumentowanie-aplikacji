import pandas as pd
import matplotlib.pyplot as plt

# bezpieczne wczytanie CSV
df = pd.read_csv("wyniki.csv", sep=';', encoding="utf-8-sig")

print(df)

# przygotowanie kolumny czas_s
df["czas_s"] = (
    df["czas_s"]
    .astype(str)
    .str.replace(",", ".", regex=False)
    .str.replace(" s", "", regex=False)
    .str.strip()
    .astype(float)
)

# wykres
plt.figure()
plt.plot(df.index, df["czas_s"], marker='o')
plt.title("Czas sortowania (sekundy)")
plt.xlabel("Pomiar")
plt.ylabel("Czas [s]")
plt.grid(True)
plt.show()
