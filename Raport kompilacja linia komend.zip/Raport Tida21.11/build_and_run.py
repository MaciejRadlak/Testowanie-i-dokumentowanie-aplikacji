import subprocess,datetime

source="main.cpp"
exe="program.exe"

subprocess.check_call(["cl",source,"/Od","/MDd",f"/Fe{exe}"])

result=subprocess.run([exe],capture_output=True,text=True)

stamp=datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
log_name=f"output_{stamp}.log"
with open (log_name, "w", encoding ="utf-8")as f:
    f.write(result.stdout+"\n")
    f.write("Uzyta wersja : Debug \n")
    f.write("KONIEC LOGU \n")
    
print("Zapisano:",log_name)

